﻿namespace ProductService.DTOs
{
    public class ProductFilter
    {
        public List<string>? ItemCode { get; set; }
        public List<string>? Labs { get; set; }
        public List<string>? Color { get; set; }
        public List<string>? Type { get; set; }
        public List<string>? Eligibility { get; set; }
        public List<string>? Clarity { get; set; }
        public List<string>? Cut { get; set; }
        public List<string>? Polish { get; set; }
        public List<string>? Symmetry { get; set; }
        public List<string>? Fluorescence { get; set; }
        public List<string>? Location { get; set; }
        public decimal? PriceFrom { get; set; }
        public decimal? PriceTo { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string? SearchTerm { get; set; }
        public string? SortBy { get; set; }
        public string? SortDirection { get; set; } = "asc";
    }
}
