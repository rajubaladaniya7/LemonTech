﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using ProductService.Data;
using ProductService.DTOs;
using ProductService.Models;
using ProductService.Repositories;
using System.Text.Json;

namespace ProductService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _repository;
        private readonly AppDbContext _context;
        private readonly IMemoryCache _cache;

        public ProductController(IProductRepository repository, AppDbContext context, IMemoryCache cache)
        {
            _repository = repository;
            _context = context;
            _cache = cache;
        }

        [HttpPost("search")]
        public async Task<IActionResult> SearchProducts([FromBody] ProductFilter filter)
        {
            string cacheKey = JsonSerializer.Serialize(filter);

            if (!_cache.TryGetValue(cacheKey, out (List<Product> products, int total) cachedResult))
            {
                var query = _repository.GetFilteredQuery(filter);

                var productType = typeof(Product);
                if (!string.IsNullOrEmpty(filter.SortBy) && productType.GetProperty(filter.SortBy) != null)
                {
                    query = filter.SortDirection?.ToLower() == "desc"
                        ? query.OrderByDescending(p => EF.Property<object>(p, filter.SortBy))
                        : query.OrderBy(p => EF.Property<object>(p, filter.SortBy));
                }

                try
                {
                    int total = await query.CountAsync();

                    var products = await query.Skip((filter.PageNumber - 1) * filter.PageSize)
                                              .Take(filter.PageSize)
                                              .ToListAsync();
                    
                    cachedResult = (products, total);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, "An error occurred while processing the request.");
                }

                // Set cache
                _cache.Set(cacheKey, cachedResult, new MemoryCacheEntryOptions
                {
                    SlidingExpiration = TimeSpan.FromHours(1)
                });
            }

            return Ok(new
            {
                Data = cachedResult.products,
                TotalCount = cachedResult.total,
                PageNumber = filter.PageNumber,
                PageSize = filter.PageSize
            });
        }
    }
}