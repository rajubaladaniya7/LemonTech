﻿namespace ProductService.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ItemCode { get; set; }
        public string Lab { get; set; }
        public string Color { get; set; }
        public string Type { get; set; }
        public string Eligibility { get; set; }
        public string Clarity { get; set; }
        public string Cut { get; set; }
        public string Polish { get; set; }
        public string Symmetry { get; set; }
        public string Fluorescence { get; set; }
        public string Location { get; set; }
        public decimal? BasePrice { get; set; }
        public decimal? Discount { get; set; }
        public decimal? Price => BasePrice - (BasePrice * Discount / 100);
    }
}
