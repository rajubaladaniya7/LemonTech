﻿using ProductService.Data;
using ProductService.DTOs;
using ProductService.Models;

namespace ProductService.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext _context;

        public ProductRepository(AppDbContext context)
        {
            _context = context;
        }

        public IQueryable<Product> GetFilteredQuery(ProductFilter filter)
        {
            var query = _context.Products.AsQueryable();

            if (filter.Labs?.Any() == true)
                query = query.Where(p => filter.Labs.Contains(p.Lab));

            if (filter.Color?.Any() == true)
                query = query.Where(p => filter.Color.Contains(p.Color));

            if (filter.Type?.Any() == true)
                query = query.Where(p => filter.Type.Contains(p.Type));

            if (filter.Eligibility?.Any() == true)
                query = query.Where(p => filter.Eligibility.Contains(p.Eligibility));

            if (filter.Clarity?.Any() == true)
                query = query.Where(p => filter.Clarity.Contains(p.Clarity));

            if (filter.Cut?.Any() == true)
                query = query.Where(p => filter.Cut.Contains(p.Cut));

            if (filter.Polish?.Any() == true)
                query = query.Where(p => filter.Polish.Contains(p.Polish));

            if (filter.Symmetry?.Any() == true)
                query = query.Where(p => filter.Symmetry.Contains(p.Symmetry));

            if (filter.Fluorescence?.Any() == true)
                query = query.Where(p => filter.Fluorescence.Contains(p.Fluorescence));

            if (filter.Location?.Any() == true)
                query = query.Where(p => filter.Location.Contains(p.Location));

            //if (filter.PriceFrom.HasValue)
            //    query = query.Where(p => p.Price >= filter.PriceFrom);

            //if (filter.PriceTo.HasValue)
            //    query = query.Where(p => p.Price <= filter.PriceTo);

            return query;
        }
    }
}
