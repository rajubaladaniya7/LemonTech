﻿using ProductService.DTOs;
using ProductService.Models;

namespace ProductService.Repositories
{
    public interface IProductRepository
    {
        IQueryable<Product> GetFilteredQuery(ProductFilter filter);
    }
}
